/*myvector.h*/

// 
// John D. McDonald
// U. of Illinois, Chicago
// CS 251: Fall 2019
// 
// Project #01: myvector class that mimics std::vector, but with my own
// implemenation outlined as follows:
//
// I created a linked list with three elements.  The first element is of type T to store data.  The second
// element is an int to store the node's position within an index.  The third node is a pointer to the next node.
// The index allows me to traverse through the list and find a given node by its index number and then manipulate that node
// as necessary for the given task.  
//
// Upside of Approach:
//   The only upside is that it is that it is an alternative to a fixed array with 1,000 elements in it, which we were told we 
//   could not use.  I address that option under "alternatives".
//   Specifically, with the linked list, you don't consume memory that you don't need.  You also don't have the danger, like
//   you do with a fixed array, of 
//
// Downside of Approach:
//    The downside of the approach is that simply accessing and modifying a given node requires traversal of some or all of
//    the nodes before we can implement the insertion or the deletion. This is very time consuming.  
//    I also added an "index" element which I realize may not be strictly necessary, but it made it easier for me
//    to follow and test what I was doing and also made it easier to create the range function.
//    It also made it harder to make the erase function, however.
//
// Obvious Alternative:
//    The most obvious alternative (but I understood we couldn't use this) is to simply create a fixed array with more memory
//    than we expect we will need.  So, since we only have 808 reviews, we could create an array with 1,000 spaces in it.  
//    The advantage of this is it is REALLY simple to code.  It is also REALLY fast to access and manipulate.  We don't have to 
//    traverse an entire list to find one element. 
//    The most obvious downside, of course, is that we consume a tremendous amount of memory we may never need.  
//    A less obvious downside is that if we happen to get a new file with 1001 reviews, then our program's insertion of that
//    last bit of data will likely screw up some other memory address that is not within our array, which could create problems
//    that we cannot predict.  That is one of the primary advantages of a vector over an array.  You can't insert data outside of
//    the memory addresses allocated to the vector.

#pragma once

#include <iostream>  // print debugging
#include <cstdlib>   // malloc, free

using namespace std;

template<typename T>
class myvector {

 private:
  // This creates a structure for a NODE to be used in a linked list
  // The node has three elements, a data element of malleable type, an integer to store the node's index
  // A pointer to the next node
  
  // I left this code in here, even though it is not used
  T*   A;
  int  Size;
  int  Capacity;
  
  // This creates my node structure
  // It is like typical node structure, but I added an index element
  struct Node {
   T data;         // This element of the node stores whatever data is required    
   int index;      // This element stores the index position of the node
   Node* next;     // This is a pointer to the next node in the list
  };
  
  // Declare Pointers that will be Used In Various Functions
  Node* newNode;  // This will be the pointer used to create a new node
  Node* headNode; // This will be the pointer to keep track of the first node in the chain
  Node* tempNode; // This will be the pointer to the tempNode that will allow us to link previous and subsequent nodes 
  Node* pointer;  // Used as a general purpose node pointer for list traversing
  
  
public:

  // Default Constructor: This Code Creates a New PseudoVector With No Fixed Size 
  myvector()  {

     newNode = new Node;
       newNode -> data = -1;
       newNode -> index = 0;
       newNode -> next = NULL;
     headNode = newNode;
     tempNode = newNode;
  }

  // constructor with initial size:  I didn't really see why we needed this function since it is not used
  // Nevertheless, this function creates "initial_size" number of nodes 
  // I seeded each node with data of -1 to act as a sentinel and indicate to me that there is no
  // valid data in the node.
  myvector(int initial_size) {
     newNode = new Node;
      newNode -> data = -1;
      newNode -> index = 0;
      newNode -> next = NULL;
     headNode = newNode;
     tempNode = newNode;
      for (int i = 1; i <= initial_size; ++i) {
        newNode = new Node;
         newNode -> data = -1;
         newNode -> index = i;
         newNode -> next = NULL;
        tempNode->next = newNode;
        tempNode = newNode;
     }
  };


  // copy constructor for parameter passing:
  myvector(const myvector& other) {
    //
    // we have to make a copy of the "other" vector, so...
    //
   
    A = new T[other.Capacity];  // allocate our own array of same capacity
    Size = other.Size;            // this vector is same size and capacity
    Capacity = other.Capacity;

    // make a copy of the elements into this vector:
    for (int i = 0; i < Size; ++i){
      A[i] = other.A[i];
    }
  }
  
  // Size function
  // The Size Function Traverses the Linked List and Returns the
  // Number of Traversals
  int size() {
    int Size = 0;
    pointer = headNode;
    while (pointer->next != NULL) {
        Size = Size + 1;
        pointer = pointer->next;
    }
    return Size;
  }

  // .at Function 
  // This function accepts i as a parameter and then traverses the linked list
  // until such time as it finds the node associated with that index.
  // It then returns the value of the data in the node associated with that index.  
  T& at(int i) {

    // Returns the Data in the Node that is Associated with that index value 
    pointer = headNode;
    while (pointer->index != i) {
      pointer=pointer->next;
    }
     return pointer->data;
  }
  
   // This function fills in the last node in the existing linked list by
   // changing the value in its "data" element to equal "value".
   // It then adds a new node seeded with data equal to the sentinal -1.
  void push_back(T value) {
   pointer = headNode;   
   while (pointer->next != NULL) {
       pointer = pointer->next;
   }
   pointer->data = value;
   int z = pointer->index;
   newNode = new Node;
      newNode->data = -1;
      newNode->index = z+1;
      newNode->next = NULL;
   pointer->next = newNode;
  }

};
