/*myvector.h*/

// 
// John D. McDonald
// U. of Illinois, Chicago
// CS 251: Fall 2019
// 
// Project #01: myvector class that mimics std::vector, but with my own
// implemenation outlined as follows:
//
// 1. The class is declared.
// 2. The 'attributes' of the class consist of a pointer to a memory location, its size, and its capacity.  
//    The attributes are private and cannot be changed by the main subroutine.
// 3. The 'methods' of the class consist of the following distinct functions which are intended to mirror each of the following
//    actions you can perform with the standard vector class:
//    (i)    creation of a vector of 0 size;
//    (ii)   creation of a vector of specified size;
//    (iii)  copying the contents of vector B into vector A
//    (iv)   display the size of a vector [vector name].size
//    (v)    accessing a specific vector location [vector name].at(location)
//    (vi)   allow a new value to be 'pushed' into the end of a vector at the end just like push_back in standard library
//    (vii)  allow the user to specify an index value, then return the data in the node associated with that index value, and then
//           deleting the node
//    (viii) allow the user to access a node using [ ] instead of .at()
//    (ix)   allow the user to access an array filled with a range of data from node i to node j inclusive  
// 4. Additional Feature (10%): The additional "feature" that this implementation adds is the ability to quickly get to the desired node 
//    in the situation where the user sequentially accesses nodes.  I used this feature three times in
//    the code below in the .at, [], and rangeof functions below. 
// 5. Motivations (Pros vs. Cons):
//    (a) I used a linked list because we were told not to use a dynamically allocated array.
//    (b) I could have used an array of fixed size, but that would not truly mimic a vector. It 
//        would consume tremendous memory even if not needed and it would fail if we had more than that
//        fixed number of reviews.
//    (c) We discussed creating an "array" of pointers in Lab, but I didn't see how it would be faster
//        than the solution that was shown in class.        

#pragma once

#include <iostream>  // print debugging
#include <cstdlib>   // malloc, free

using namespace std;

template<typename T>
class myvector
{
private:
  // These Variables Were Given to Us to Use.
  T*   A;             
  int  Size;          
  int  Capacity;      
  
  // I added the Following New Structs and Variables.
 
  // This is the structure for each NODE in my linked list.
  struct NODE
  {
    T            Data;
    struct NODE* Next;
  };
  
  // I created a pointer for the Head of the Linked List and a Tail of the Linked List.
  // I created a pointer called newNode to use whenever I need to create a new NODE.
  // I created a pointer to the previous NODE that was accessed called lastNode.
  // I created a generic pointer just to make it easier to traverse the list when I need to.
  // I created two pointers to distinguish between the current NODE (curNode) and the NODE that that
  // NODE is pointing to (sucNode) when I need to remove a NODE.
  struct NODE* Head;
  struct NODE* Tail;
  struct NODE* newNode;
  struct NODE* lastNode;
  struct NODE* Pointer;
  struct NODE* curNode;
  struct NODE* sucNode;
  
  // I created a variable to store the last index number that was called with the .at function.
  int lastIndex; 
  
public:
  // This is my default constructor, which creates an "instance" of the myvector class with
  // no initial Size or Capacity.
  myvector()
  {
     Head = nullptr;
     Tail = nullptr;
     Size = 0;
     Capacity = 0;
     
     lastNode = nullptr;
     lastIndex = -1;
     return;
  }

  // This is my constructor for the situation where the vector is created with an initial size
  // or number of nodes.
  myvector(int initial_size)
  { 
     // I created an iterator.
     int i;
     
     Head = nullptr;
     Tail = nullptr;
     Size = 0;
     Capacity = 0;
     lastNode = nullptr;
     lastIndex = -1;
     
     if (initial_size < 0) 
     {
       cout << "This is an improper size.  Choose a positive number.";
       return;
     }
     
     if (initial_size == 0) 
     {
         return;
     }     
     
     newNode = new struct NODE;
     newNode->Data = T{};
     newNode->Next = nullptr;
     
     // We create the first Node because we know initial_size has to equal at least 1.
     Head = newNode;
     Tail = newNode;
     Size = 1;
     Capacity = 1;
     
     // We start at 1 because we created the first node already.
     for (i = 1; i < initial_size; ++i)
     {
         push_back(T{});
     }
     return;
  }


  // copy constructor for parameter passing:
  // The "other" vector is the vector that holds the data that we want to copy.
  // The instance of the vector that we want to copy "to" can be accessed using the this-> command.
 myvector(const myvector& other)
  {
      struct NODE* TempNode = new struct NODE();
      TempNode = other.Head;
      this->Head = nullptr;
      this->Tail = nullptr;
      
      while (TempNode != nullptr)
      {
          push_back(TempNode->Data);
          TempNode = TempNode->Next;
      }
      
      this->Size = other.Size;
  }
  
  // size() function:
  // It simply returns the value stored in the Size variable at that moment in time.
  int size()
  {
    return Size;
  }
  
  // .at(int i) function:
  // This function accepts an integer as an argument.
  // It returns the NODE in the linked list that is associated with the index value that
  // is equal to the integer.
  T& at(int i)
  {
    if (i==0) 
    {
        lastNode = Head;
        lastIndex = 0;
        return Head->Data;
    } 
    else if (i == lastIndex+1) 
    {
        //We know that the user wants the data in lastNode->Next.
        //Thus, we can just access that data directly in one step.
        
        //First, we advance lastNode to lastNode->Next
        lastNode = lastNode->Next;
        
        //Second, we update lastIndex to i.
        lastIndex = i;
        
        //Third, we return the data in the proper Node.
        return lastNode->Data;
    }
    
    else 
    {
      // We know at this point we are not accessing elements consecutively.
      // Thus, we have to traverse the list to find the right NODE.
      int counter;
      Pointer = Head;
      counter = 0;
      
      while (counter != i) {
          Pointer=Pointer->Next;
          counter=counter+1;
      }
      
      // At this point, Pointer should be pointing to the correct NODE.
      return Pointer->Data;
    } 
  }
  
  // push_back function:
  // This function accepts a value of type T. 
  // It then creates a new NODE at the end of the linked list and places the value
  // into the Data element of that last NODE.
  void push_back(T value)
  {
      newNode = new NODE;
      newNode->Data = value;
      newNode->Next = nullptr;
    
    curNode = Head;
    
    // Scenario: The Head NODE has not been created
    if (curNode == nullptr) 
    {
      Head = newNode;
      Tail = newNode;
      Size = Size + 1;
      return;
    }
    
    Tail->Next=newNode;
    Tail = newNode;
    Size = Size + 1;
    return;
  }
  
//  PART 04: Functions:  The Following Additional Functions Were Added Specifically
//  for Part 04 of the Project.

    //erase function:
    //This function accepts a single integer as an argument. 
    //The purpose of this function is to: 
    //  - find the NODE associated with that index integer;
    //  - store the Data in that NODE;
    //  - remove that NODE;
    //  - return the data in the NODE that was shifted backward into the deleted NODE's place.
    
    T erase (int i) 
    {
        T returnedData;
    
        // Address the Situation Where the Head is Removed.
        if (i == 0) 
        {
        // Store Data in Node to be Removed
        returnedData = Head->Data;
        
            //Address Situation Where Head == Tail
            if (Head == Tail) 
            {
            // Eliminate Head and Tail Node Reduce to Vector of No Size
            Head = nullptr;
            Tail = nullptr;
        
            //Decrement Size
            Size = Size - 1;
            } else {
            // Address Situation Where Head != Tail
            curNode = Head;
            sucNode = Head->Next;
            Head = sucNode;
            delete(curNode); 

            //Decrement Size
            Size = Size - 1;
            }
        
        //Return Data Stored in Removed Element
        return returnedData;
        }
        
        // Traverse the List to Find the ith NODE.
        int counter;
        counter = 0;
        Pointer = Head;
        
        while (counter != (i-1)) 
        {
            Pointer = Pointer->Next;
            counter = counter+1;
        }
        
        // The Pointer Should Now be Pointing at the NODE before the ith position.
        curNode = Pointer;
        
        // sucNode should be the NODE in the ith position.
        sucNode = Pointer->Next;
        
        returnedData = sucNode->Data;
        
        // sucNode may be the Tail or may not be the Tail
        // sucNode = Tail 
        if (sucNode == Tail)
        {        
            curNode->Next = nullptr;
            Size = Size - 1;
            //delete(sucNode);  // May not be needed
            return returnedData; 
        } else {
            curNode->Next = sucNode->Next;
            Size = Size - 1;
            //delete(sucNode); // May not be needed
            return returnedData;
        }
    }
    
    // [] function:
    // This function simply allows the user to access the linked list by
    // stating V[3] instead of V.at(3).   
    T& operator[](int i)
    {   
        return at(i);
    }

    // rangeof function:
    // This function creates a dynamically allocated array.
    // This function takes two integers i and j.
    // The function then traverses through the linked list to find the ith element.
    // It then copies the ith througgh jth elements to a dynamically allocated array. 
    T* rangeof(int i, int j) 
    {
      // Create a General Purpose Iterator.
      int p;

      // Create a variable to store the range.
      int range; 
      range = j - i + 1;
      
      // Create a variable to store a counter.
      int counter;
      counter = 0;
      
      // A pointer to A was Created in Private.
      // We allocate memory sufficient for type T data of size 'range' to it dynamically here.
      A = new T[range];
      
      for (p = i; p < j + 1; ++p)
      {
          A[counter] = at(p);
          counter = counter + 1;
      }
      
      return A;     
    }

};