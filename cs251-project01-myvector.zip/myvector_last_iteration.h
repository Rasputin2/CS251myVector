/*myvector.h*/

// 
// John D. McDonald
// U. of Illinois, Chicago
// CS 251: Fall 2019
// 
// Project #01: myvector class that mimics std::vector, but with my own
// implemenation outlined as follows:
//
// I created a linked list with two elements.  The first element is of type T to store data.  The second 
// element of the node is a pointer to the next node.
// 
// I chose a singly-linked list implementation, to reduce the elements in each node and, hence,
// the amount of memory consumed.  
//
// Upside of Approach:
//   The only upside is that it is that it is an alternative to a fixed array with 1,000 elements in it, which we were told we 
//   could not use.  I address that option below under "alternatives".
//   Specifically, with the linked list, you don't consume memory that you don't need.  You also don't have the danger, like
//   you do with a fixed array, of, for example, 1000 elements. 
//
// Downside of Approach:
//    The downside of the approach is that simply accessing and modifying a given node requires traversal of some or all of
//    the nodes before we can implement the insertion or the deletion. This is very time consuming.  It is not a huge drawback
//    given the number of nodes is less than 1000+, but if we had more it would be a problem.
//
// Obvious Alternative:
//    The most obvious alternative (but I understood we couldn't use this) is to simply create a fixed array with more memory
//    than we expect we will need.  So, since we only have 808 reviews, we could create an array with 1,000 spaces in it.  
//    The advantage of this is it is REALLY simple to code.  It is also REALLY fast to access and manipulate.  We don't have to 
//    traverse an entire list to find one element. 
//    The most obvious downside, of course, is that we consume a tremendous amount of memory we may never need.  
//    A less obvious downside is that if we happen to get a new file with 1001 reviews, then our program's insertion of that
//    last bit of data will likely screw up some other memory address that is not within our array, which could create problems
//    that we cannot predict.  That is one of the primary advantages of a vector over an array.  You can't insert data outside of
//    the memory addresses allocated to the vector.

#pragma once

#include <iostream>  // print debugging
#include <cstdlib>   // malloc, free

using namespace std;

template<typename T>
class myvector {

 private:
    
  // I left this code in here, even though it is not used.
  // I believe this is in here for the undisclosed "alternative" to a linked-list.
  // Since I used a Linked List, I didn't use this code, but I left it here as as
  // a placeholder.
  T*   A;
  int  Size;
  int  Capacity;
  
  // This is the structure of my Nodes in my Linked List
  struct Node {
   T data;         // This element of the node stores whatever data is required    
   Node* next;     // This is a pointer to the next node in the list
  };
  
  // Declare Pointers that will be Used In Various Functions
  Node* newNode;  // This will be the pointer used to create a new node.
  Node* headNode; // This will be the pointer to keep track of the first node in the chain.
  Node* tempNode; // This will be the pointer to the tempNode that will allow us to link
                  // previous and subsequent nodes.
  Node* pointer;  // Used as a general purpose node pointer for list traversing.  I realize
                  // that I could have used tempNode, but this helps me keep the concepts straight
                  // in my head.
                  
  
  
public:

  // Default Constructor: This Code is Called when the User does not Specify a Size. 
  // The reason I create two nodes is that I always create an extra node at the 
  // end that points to NULL to act as a sentinel. 
  myvector()  {
     // Create First Node
     // The assignment of -1 to the data element signifies that although
     // this node has been created, the data in it is not valid data.  It 
     // is simply a placeholder.
     newNode = new Node;
       newNode -> data = -1;
       newNode -> next = NULL;
     headNode = newNode;
     tempNode = newNode;
     // Create Second Node to Act as Tail of List
     newNode = new Node;
       newNode -> data = -1;
       newNode -> next = NULL;
     headNode->next = newNode;
  }

  // constructor with initial size:  
  // This function creates "initial_size" + 1 number of nodes.  I add one node to act as my sentinel.
  // I seeded each node with data of -1 to indicate that the node does not contain valid data. 

  myvector(int initial_size) {
     newNode = new Node;
      newNode -> data = -1;
      newNode -> next = NULL;
     headNode = newNode;
     tempNode = newNode;
      for (int i = 1; i < initial_size + 1; ++i) {  // NOTE THAT I USE EQUAL HERE TO ADD A SENTINEL NODE AFTER INITIAL SIZE
        newNode = new Node;
         newNode -> data = -1;
         newNode -> next = NULL;
        tempNode->next = newNode;
        tempNode = newNode;
     }
  };

/* NOTE: COME BACK TO AFTER SPEAKING WITH TA
  // copy constructor for parameter passing:
  myvector(const myvector& other) {
    
    // Determine Size of Linked List Named Other
    int counter = 0;
    pointer = headNode;  
    while (pointer->next != NULL) {
        counter=counter+1;
        pointer = pointer->next;
    }
    
    // Create a New Linked List 'Other' with Same Data in its Nodes as
    // the Data in The Class that was Used to Call This Function (i.e., Reviews)
    // The reason other.headNode should already exist is because we "assume"
    // that myvector [name of other] () has been called already
   
    // Create headNodeOther and tempNodeOther to distinguish from headNode
    Node* headNodeOther = other.headNode;
    Node* tempNodeOther = other.headNode;
    
    // This resets the pointer to point to headNode of the class that called
    // this function (i.e., reviews head node)
    pointer = headNode;
    tempNodeOther->data = pointer->data; 
    
    for (int i = 0; i < counter; ++i) {
      newNode = new Node;
      newNode->data = pointer->data;
      newNode->next = pointer->next;
       
         
    }
    
      // NOTE: SHOULD WE RETURN A?
      
    NOTE: I am commenting this out because I am using a linked list
 //   Size = 0; 
 //   A = new T[other.Capacity];  // allocate our own array of same capacity
 //   Size = other.Size;            // this vector is same size and capacity
 //   Capacity = other.Capacity;

 //   // make a copy of the elements into this vector:
 //   for (int i = 0; i < Size; ++i) { 
 //     A[i] = other.A[i];
 //     }
      
  }
  */
       
  // size() function:
  // The purpose of this function is to determine how many nodes 'exist'. 
  // Given the way I set up my linked list, there is always one extra node that points to NULL and has -1 as data.
  // Thus, if I have 6 nodes, this will only return 5.  If I have 7 nodes, it will return 6.  
  // In Part 03, I used an index, but now that I am using this approach, 
  int size() {
    int Size = 0;
    pointer = headNode;
    while (pointer->next != NULL) {
        Size = Size + 1;
        pointer = pointer->next;
    }
    return Size;
  }

  // .at function:
  // The purpose of this function is to allow the user to find the data stored within a specific
  // node.  The function takes in an int and returns the data in the node associated with that int. 
  T& at(int i) {

    // Returns the Data in the Node that is Associated with that index value 
    pointer = headNode;
    int counter = 0;
     
      while (counter != i) {
        pointer=pointer->next;
        counter = counter + 1;  
      }
      
     return pointer->data;
  }
  
   // This function fills in the last node in the existing linked list by
   // changing the value in its "data" element to equal "value".
   // It then adds a new node (which serves as my "tail") seeded with data equal to the sentinal -1.
  void push_back(T value) {
   pointer = headNode;   
   while (pointer->data != -1) {
       pointer = pointer->next;
   }
   pointer->data = value;
   
   // The following Code checks whether the next node is the tail with invalid data.
   // If it is, then nothing happens.
   // If it is not, then a new node (tail) is created with placeholder data -1.
   
   if (pointer->next != NULL) {
       // Nothing happens in this case.
   } else {
      newNode = new Node;
      newNode->data = -1;
      newNode->next = NULL;
   pointer->next = newNode;
   }
  }


  // Part 04: Erase Function
  // This function does many things.  
  // First, it finds Node i.
  // Second, it points Node i-1 to Node i+1.
  // Third, it frees up Node i.
  // Finally, it returns the data found in the Node that was formerly
  // at i+1, but is now at i.

  T erase(int i) {
   // First we have to find the correct node
   
   // We first deal with the situation where the headNode is
   // to be deleted.
   if (i==0) {
     pointer = headNode->next;
     free(headNode);
     headNode = pointer;
     return headNode->data;
   }
   
   // The following Code addresses the scenario where a Node
   // after the headNode is to be deleted.
   int counter = 0;
   pointer = headNode;
    // Find the node prior to the node to be erased  
    while (counter < i-1) {
      pointer = pointer->next;
      counter = counter + 1;
    }
   // At this point, pointer is pointing to the i-1 Node.
   // We now assign tempNode to the i Node position.  
   tempNode = pointer->next;
   
   // Now we have to determine if this node is the last node in the list or not.
   // If it is not, then we need to push all the nodes back one position.
   // If it is, then we simply delete it and cause the i-1 Node to point to NULL.
   if (tempNode->next != NULL) {
     // We know that the ith Node is not the tail. 
     // We need to bypass tempNode by causing pointer->Next to point to tempNode->Next.
     // This should cause the i-1 node to point to the i+1 node directly, bypassing the
     // i Node which we want to free up.
     pointer->next = tempNode->next;
   
     // Now we can free up the i Node in tempNode, because we don't care about it anymore.
     free(tempNode);
   
     // Return the value in the node after the node to be erased
     // which should now be stored in tempNode->next->data  
     return pointer->next->data;
   } else {
     // We know that the ith Node IS the tail.
     // So, all we do is cause the i-1 pointer to point to NULL.  Now
     // it becomes our tail.  
     pointer->next = NULL;
     // We free up/destroy tempNode as it is no longer storing anything.
     free(tempNode);
     return pointer->data;
   }
  }
    
  // Part 04: operator[] function
  // 
  
  // Part 04: rangeof function
  // This function accepts two integers as arguments.
  // The function finds the data in the Nodes of the linked list associated with those
  // two integers.  
  // It then returns a pointer to an array which holds that data. 
  T* rangeof (int i, int j) {
     int n;  // Creates an integer variable to store the size of the array.
     int counter;  // Creates an integer variable for iteration and traversal.
     int k;
      
     n = i - j + 1;  // This establishes the size of the array (4 - 2 + 1 = 3). 
     static T Array[n];
     pointer = headNode;
     
     counter = 0;
     
     while (counter != i) {
       pointer = pointer->next;
       counter = counter + 1;
     }
     
     // At this point, pointer should equal the Node in the ith position
     for (k = 0; k < n; ++k) {
       Array[k] = pointer->data;
       pointer = pointer->next;
     }
     
     return Array;
      
  }

};