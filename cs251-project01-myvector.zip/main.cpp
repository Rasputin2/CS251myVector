//
// Project #01: input movie review data from a file, and output moviename, # of 
// reviews, average review, and # of reviews per star.
//
// File example "movie1.txt":
//   Finding Nemo
//   5
//   4
//   5
//   4
//   5
//   -1
//
// Output:
//  Movie: Finding Nemo
//  Num reviews: 5
//  Avg review:  4.6
//  5 stars: 3
//  4 stars: 2
//  3 stars: 0
//  2 stars: 0
//  1 star:  0
//

#include <iostream>
#include <fstream>
#include <string>

#include "myvector.h"

using namespace std;

// functions from student.cpp:
myvector<int> InputData(string filename, string& moviename);
double   GetAverage(myvector<int> reviews);
myvector<int> GetNumStars(myvector<int> reviews);

int main()
{
  myvector<int>  reviews;
  myvector<int>  numstars;
  double    avg;
  string    filename, moviename;

  //
  // 1. input filename and then the review data:
  //
  cin >> filename;

  reviews = InputData(filename, moviename);

  cout << "Movie: " << moviename << endl;
  cout << "Num reviews: " << reviews.size() << endl;
    
  // 2. average review
  //
  avg = GetAverage(reviews);
  cout << "Avg review:  " << avg << endl;

  // 3. # of 5 stars, 4 stars, etc
  //
  numstars = GetNumStars(reviews);
  
  for (int i = numstars.size(); i > 0; --i)   
  {
    //
    // i is 5, 4, 3, 2, 1:
    //
    if (i == 1)
      cout << i << " star:  " << numstars.at(i - 1) << endl;
    else
      cout << i << " stars: " << numstars.at(i - 1) << endl;
  }
    
  // NOTE: FOR TESTING PART 04 ONLY
  /* 
  // Test Erase Function:
  int j;
  cout << "Enter element # to be erased:";
  cin >> j;
  reviews.erase(j);
  cout << "New Size: " <<reviews.size() << endl;
  for (j = 0; j<reviews.size(); ++j) {
      cout << reviews.at(j) << endl;
  }
    
  // Test [] Function:
  int k;
  int l;  
  cout << "Enter index value of reviews to be accessed: ";
  cin >> k;
  cout << "Enter index value of numstars to be accessed: ";  
  cin >> l;  
  cout << "Reviews Element: " << reviews[k] << endl;
  cout << "Numstars Element: " << numstars[l] << endl;
  */

  // Test rangeof function.

//  int i;
//  int j;

//  cout << "Enter i for reviews: " << endl;
//  cin >> i;
//  cout << "Enter j for reviews: " << endl;
//  cin >> j;
 
//  int *Array = reviews.rangeof(i,j);

//  cout << "Array Contents: " << endl;  
//  cout << Array[0] << endl;
//  cout << Array[1] << endl;
//  cout << Array[2] << endl;
//  cout << Array[3] << endl;
  
    
  //TEST COPY CONSTRUCTOR  
  /*  
  myvector<int>  VRT1;
  myvector<int>  VRT2;
    
  VRT1.push_back(1);
  VRT1.push_back(2);
  VRT1.push_back(3);

  vector<int> VRT2 = VRT1;  // copy construct:

  VRT2.push_back(4);
  VRT2.push_back(5);
  VRT2.push_back(6);
 
  // Now output the size and elements of V1: size 1, elements just 123.

  cout << "This is VRT1: " << endl;
    cout << "Size: " << VRT1.size();
    cout << VRT1.at(0) << endl;
    cout << VRT1.at(1) << endl;
    cout << VRT1.at(2) << endl;
    
  // Now output the size and elements of V2: size 2, elements 123 456.
  cout << "This is VRT2: " << endl;
    cout << "Size: " << VRT2.size();
    cout << VRT2.at(0) << endl;
    cout << VRT2.at(1) << endl;
    cout << VRT2.at(2) << endl;
    
   */
  
/* // TEST_CASE("Test 11", "[Project01]")

  myvector<int>  V(25);

  //REQUIRE(V.size() == 25);

  for (int i = 0; i < 25; ++i) {
      cout << "V[" << i <<"] :"  << V[i] << endl;
  }
      
      
//    REQUIRE(V[i] == 0);

  // copy constructor:
  myvector<int>  V2 = V;

  cout << "Size of V2: " << V2.size() << endl;
      
//  REQUIRE(V2.size() == 25);

  for (int i = 0; i < 25; ++i){
      cout << "V2[" << i <<"] : " << V2[i] << endl;
  }
      
      
      
//    REQUIRE(V2[i] == 0);

  V2[0] = 999;
  V2[1] = 998;
  V2[24] = 222;
  V2[12] = 989;
  V2[11] = 990;

    cout << V2[0] << endl;
    cout << V2[1] << endl;
    cout << V2[24] << endl;
    cout << V2[12] << endl;
    cout << V2[11] << endl;
    

  // make sure original vector didn't change:
  for (int i = 0; i < 25; ++i){
     cout << "V[" << i <<"] : " << V[i] << endl;
//    //    REQUIRE(V[i] == 0);
    }
 */  
    
   // TEST_CASE("Test 12", "[Project01]")
{
  cout << "Starting range of: " << endl;
  myvector<int>  V;

  int N = 100;

  for (int i = 0; i < N; i++){
    V.push_back(i * 10);
    cout << "V[" << i << "]:" << V.at(i) << endl; 
  }
//  REQUIRE(V.size() == N);

    cout << "Size of V: " << V.size() << endl;
    
  // range of 10 elements [0..9]:
  int* B = V.rangeof(0, 9);

  for (int i = 0; i < 10; ++i){
      cout << "B[" << i << "]" << B[i] << endl;
  }
//    REQUIRE(A[i] == (i * 10));
}
    
 
   // TEST_CASE("Test 13", "[Project01]")

{
  myvector<int>  V;

  int N = 100;

  for (int i = 0; i < N; i++){
    V.push_back(i * 10);
    cout << "V[" << i << "]:" << V.at(i) << endl; 
   }
    
//  REQUIRE(V.size() == N);

  // just one element:
   int* B = V.rangeof(99, 99);
   
   cout << "B[0]:" << B[0] << endl;
        
//  REQUIRE(B[0] == (99 * 10));
}
    
  // END OF TESTING PART 04
    
  return 0;
}
